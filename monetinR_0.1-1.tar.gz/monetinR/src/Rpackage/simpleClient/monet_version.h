#ifndef MONETDB_VERSION_H
#define MONETDB_VERSION_H

extern void monet_version(void);

#endif /* MONETDB_VERSION_H */
