MAKE <- Sys.getenv("MAKE")
system("make install")
