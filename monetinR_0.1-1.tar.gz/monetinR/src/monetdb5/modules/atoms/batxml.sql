CREATE AGGREGATE "xmlagg"( x xml ) RETURNS xml external name xml.agg;
