echo "With cracking"
mserver5 --set monet_prompt='' <CrackSelectRangeRandom.mal
echo "Without cracking"
mserver5 --set monet_prompt='' <SelectRangeRandom.mal
