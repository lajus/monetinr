# set up the database
create table r(k int, a int);
create table s(k int, b int);
insert into r values (1,1), (1,2), (1,3);
insert into s values (1,1), (1,2), (1,3);
